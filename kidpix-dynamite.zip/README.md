# kidpix dynamite chrome extension

--

chrome extension for replicating [Kid Pix dynamite tool](https://en.wikipedia.org/wiki/Kid_Pix#Selection_and_Erasing_Tools) in-browser - blow up any website on sight.